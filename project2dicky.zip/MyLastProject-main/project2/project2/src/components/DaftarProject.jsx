import Project from "./Project";

const DAFTAR_PROJECT = [
    new Project({
        id: 1,
        name: "Jajang",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores alias mollitia totam nisi dolores perferendis ipsum nihil corporis ad molestiae dicta facere iste neque, atque earum officia sequi fugiat. Rerum atque asperiores ducimus libero, aliquid, magnam totam sit minima, veniam quisquam nihil? Voluptas fugiat velit consequuntur aut inventore vel, alias animi quam voluptates dolore! Mollitia et neque esse a dignissimos.",
        imageUrl: "/assets/placeimg_500_300_arch1.jpg",
        budget: 12000,
        isActive: true
    }),
    new Project({
        id: 2,
        name: "Surya",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores alias mollitia totam nisi dolores perferendis ipsum nihil corporis ad molestiae dicta facere iste neque, atque earum officia sequi fugiat. Rerum atque asperiores ducimus libero, aliquid, magnam totam sit minima, veniam quisquam nihil? Voluptas fugiat velit consequuntur aut inventore vel, alias animi quam voluptates dolore! Mollitia et neque esse a dignissimos.",
        imageUrl: "/assets/placeimg_500_300_arch1.jpg",
        budget: 12000,
        isActive: true
    }),
    new Project({
        id: 3,
        name: "Halim",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores alias mollitia totam nisi dolores perferendis ipsum nihil corporis ad molestiae dicta facere iste neque, atque earum officia sequi fugiat. Rerum atque asperiores ducimus libero, aliquid, magnam totam sit minima, veniam quisquam nihil? Voluptas fugiat velit consequuntur aut inventore vel, alias animi quam voluptates dolore! Mollitia et neque esse a dignissimos.",
        imageUrl: "/assets/placeimg_500_300_arch1.jpg",
        budget: 12000,
        isActive: true
    }),
    new Project({
        id: 4,
        name: "Sasa",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores alias mollitia totam nisi dolores perferendis ipsum nihil corporis ad molestiae dicta facere iste neque, atque earum officia sequi fugiat. Rerum atque asperiores ducimus libero, aliquid, magnam totam sit minima, veniam quisquam nihil? Voluptas fugiat velit consequuntur aut inventore vel, alias animi quam voluptates dolore! Mollitia et neque esse a dignissimos.",
        imageUrl: "/assets/placeimg_500_300_arch1.jpg",
        budget: 12000,
        isActive: true
    }),
    new Project({
        id: 5,
        name: "Ajis",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores alias mollitia totam nisi dolores perferendis ipsum nihil corporis ad molestiae dicta facere iste neque, atque earum officia sequi fugiat. Rerum atque asperiores ducimus libero, aliquid, magnam totam sit minima, veniam quisquam nihil? Voluptas fugiat velit consequuntur aut inventore vel, alias animi quam voluptates dolore! Mollitia et neque esse a dignissimos.",
        imageUrl: "/assets/placeimg_500_300_arch1.jpg",
        budget: 12000,
        isActive: true
    }),
]

export default DAFTAR_PROJECT